#version 330 core

attribute float isMid;

out float mid;
out vec3 color;

void main() {
	color = gl_Color.rgb;
	gl_Position = ftransform();
	mid = isMid;
}