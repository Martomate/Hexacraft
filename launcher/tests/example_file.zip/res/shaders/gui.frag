#version 130

in vec2 textureCoords;

uniform sampler2D textureIn;

void main() {
	gl_FragColor = texture(textureIn, textureCoords);
}
