#version 130

in vec2 pass_texCoords;

out vec4 out_Color;

uniform sampler2D textureSampler;
uniform vec3 colorTint;
uniform float glow = 1.0;

void main() {
	out_Color = vec4(colorTint, 1.0);//texture(textureSampler, pass_texCoords) * vec4(colorTint, 1.0);
	out_Color.r += glow - 1;
}
