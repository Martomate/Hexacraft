#version 330 core

uniform float glow;

in float mid;
in vec3 color;

void main() {
	float mult;
	if (mid < 0.1) mult = mid * 10;
	else if (mid < 0.2) mult = 1 - (mid - 0.1) * 10;
	else discard;
	
	gl_FragColor = vec4(color * mult * glow, 1);
}